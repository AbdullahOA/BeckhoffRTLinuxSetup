Beckhoff RT Linux Setup 1.2.0  -  unofficial tool by Abdullah Omar, Beckhoff UAE
(not an official or supported Beckhoff product - use at your own risk, see DISCLAIMER.txt)

WHAT YOU NEED
  - Windows 10/11 laptop with internet (Wi-Fi is fine)
  - Ethernet cable from the laptop directly to the controller (end0 on a CX9240)
  - Your myBeckhoff account (e-mail + password)
  - The controller's Administrator password (factory default: 1)

HOW TO USE
  1. Extract the zip and double-click BeckhoffRTLinuxSetup.exe
     (if Windows shows "protected your PC": More info -> Run anyway)
  2. Accept the disclaimer.

  3. Section 1 - Controller
     Pick the Ethernet adapter -> Discover -> the controller appears with its MAC.
     Enter the Administrator password -> Connect.
     The FIRST time a black window opens asking for that password again: type it,
     press Enter. This installs an SSH key; it will not ask again for this controller.

  4. Section 2 - Repository and packages
     Enter your myBeckhoff e-mail and password (leave both empty to reuse a login
     already stored on the controller).
     Optional: "Fetch package list..." shows everything available in the Beckhoff
     repository; tick what you want. Without it, the tool installs the defaults:
       tc31-xar-um, tf2000-hmi-server, tf1200-ui-client
     Optional: "Add Beckhoff testing feed" - pre-release packages, NOT for production.
     Optional: "Delete bhf.conf when finished" - removes your stored login afterwards.

  5. Section 3 - HMI server / UI client
     HMI admin password: the login for http://<controller-ip>:2020 (user __SystemAdministrator).
     UI Client user: the Linux user that runs the TF1200 UI Client (default Administrator;
     a new user is created if it does not exist). Tick autologin + autostart for a panel.
     UI Client start URL: the page the client opens (default = the local HMI server).
     Kiosk mode: full screen, no menu bar.

  6. Section 4 - IP address
     Keep DHCP, or choose Static and enter address/prefix (e.g. 192.168.1.100/24),
     optional gateway and DNS. Applied at the very end.

  7. Run setup. Keep the laptop online and the window open until it finishes.
     Packages are downloaded THROUGH the laptop, so it may take a few minutes.
     A dialog at the end shows the controller's new SSH and HMI addresses.

AFTER SETUP
  - If you chose a static IP, set the laptop's Ethernet adapter to the same subnet.
  - Reboot the controller once if you enabled UI Client autologin/autostart.
  - Change the Administrator password from the factory default:  passwd
  - Running the tool again on the same controller is safe; finished steps are skipped.

WHAT'S NEW IN 1.2.0
  - Choose which Beckhoff packages to install (fetched live from the repository)
  - Optional Beckhoff testing feed
  - Configurable Linux user for the TF1200 UI Client
  - "Delete bhf.conf" option moved to section 2
